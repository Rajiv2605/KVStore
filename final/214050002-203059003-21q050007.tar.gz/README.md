Team Members:
    Pratik Kumar 214050002
    Rajiv Vaidyanathan Natarajan 203059003
    Sumon Nath 21q050007

Build:
    make

Run:
    ./server - to run server
    ./client - to run client, then follow the instructions on command line to generate requests

Clean:
    make clean

To remove persistence files and log:
    ./clear.sh


For BATCH mode, modify the commands.txt file