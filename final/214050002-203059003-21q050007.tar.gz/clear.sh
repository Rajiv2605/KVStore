rm keydb*
rm log.txt
